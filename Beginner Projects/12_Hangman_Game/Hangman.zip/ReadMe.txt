Execute the "hangman.py" python file

>> python hangman.py